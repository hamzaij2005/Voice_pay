"""
VoicePay — twilio_app.py  (Member 1 — Voice Interface)
=======================================================
FIXED VERSION — No gTTS, No FFmpeg needed.
Uses Twilio's built-in Say for all voice output.

INSTALL:
    pip install flask twilio requests groq

SET THESE (every new terminal — PowerShell):
    $env:TWILIO_ACCOUNT_SID   = "ACb6112bcacf167becca524f04a6812f41"
    $env:TWILIO_AUTH_TOKEN    = "your_rotated_token_here"
    $env:TWILIO_PHONE_NUMBER  = "+13203145202"
    $env:GROQ_API_KEY         = "gsk_your_key_here"
    $env:BACKEND_URL          = "http://localhost:5000/process"

RUN ORDER:
    Terminal 1:  python app.py
    Terminal 2:  python twilio_app.py
    Terminal 3:  ngrok http 5001

THEN:
    Twilio Console → Phone Numbers → +13203145202
    Voice webhook → https://hedge-falcon-handcart.ngrok-free.dev/incoming
    Method: HTTP POST → Save

CALL: +1 (320) 314-5202
"""

import os
import re
import json
import requests
import warnings
warnings.filterwarnings("ignore")

from flask import Flask, request, Response
from twilio.twiml.voice_response import VoiceResponse, Gather

app = Flask(__name__)

# ── Config ────────────────────────────────────────────
ACCOUNT_SID   = os.environ.get("TWILIO_ACCOUNT_SID",  "").strip()
AUTH_TOKEN    = os.environ.get("TWILIO_AUTH_TOKEN",   "").strip()
TWILIO_NUMBER = os.environ.get("TWILIO_PHONE_NUMBER", "").strip()
BACKEND_URL   = os.environ.get("BACKEND_URL", "http://localhost:5000/process").strip()

# In-memory session store {call_sid: {sender, pin, step}}
sessions = {}

# Twilio voice — Alice sounds natural and clear
VOICE    = "alice"
LANGUAGE = "en-US"


# ══════════════════════════════════════════════════════
#  HELPER — build TwiML Say response
# ══════════════════════════════════════════════════════

def say(text: str) -> VoiceResponse:
    resp = VoiceResponse()
    resp.say(text, voice=VOICE, language=LANGUAGE)
    return resp


def say_and_gather_speech(text: str, action: str, timeout: int = 5) -> VoiceResponse:
    """Say something then listen for speech."""
    resp   = VoiceResponse()
    gather = Gather(
        input="speech",
        action=action,
        timeout=timeout,
        speech_timeout="auto",
        language=LANGUAGE,
        method="POST"
    )
    gather.say(text, voice=VOICE, language=LANGUAGE)
    resp.append(gather)
    # Redirect back if no input received
    resp.redirect(action + "&retry=1")
    return resp


def say_and_gather_dtmf(text: str, action: str,
                         num_digits: int = 4, timeout: int = 10) -> VoiceResponse:
    """Say something then listen for keypad input."""
    resp   = VoiceResponse()
    gather = Gather(
        input="dtmf",
        num_digits=num_digits,
        action=action,
        timeout=timeout,
        method="POST"
    )
    gather.say(text, voice=VOICE, language=LANGUAGE)
    resp.append(gather)
    resp.redirect(action + "&retry=1")
    return resp


# ══════════════════════════════════════════════════════
#  STEP 1 — Incoming Call → Welcome
# ══════════════════════════════════════════════════════

@app.route("/incoming", methods=["POST"])
def incoming():
    call_sid = request.form.get("CallSid", "unknown")
    from_num = request.form.get("From", "unknown")
    print(f"\n[CALL] Incoming from {from_num} | SID: {call_sid}")

    sessions[call_sid] = {"step": "await_username", "sender": None, "pin": None}

    resp = say_and_gather_speech(
        "Welcome to VoicePay Pakistan. "
        "The fast and secure voice payment service. "
        "Please say your username.",
        action=f"/get_username?call_sid={call_sid}"
    )
    return Response(str(resp), mimetype="text/xml")


# ══════════════════════════════════════════════════════
#  STEP 2 — Capture Username
# ══════════════════════════════════════════════════════

@app.route("/get_username", methods=["POST"])
def get_username():
    call_sid = request.args.get("call_sid") or request.form.get("CallSid", "")
    speech   = request.form.get("SpeechResult", "").strip().lower()
    retry    = request.args.get("retry")

    print(f"[USERNAME] Heard: '{speech}' | SID: {call_sid}")

    if not speech:
        resp = say_and_gather_speech(
            "Sorry, I did not catch that. Please say your username clearly.",
            action=f"/get_username?call_sid={call_sid}"
        )
        return Response(str(resp), mimetype="text/xml")

    # Clean — take first word, letters only
    username = re.sub(r"[^a-z]", "", speech.split()[0])
    if not username:
        resp = say_and_gather_speech(
            "Sorry, I could not understand that. Please say your username again.",
            action=f"/get_username?call_sid={call_sid}"
        )
        return Response(str(resp), mimetype="text/xml")

    if call_sid in sessions:
        sessions[call_sid]["sender"] = username
        sessions[call_sid]["step"]   = "await_pin"

    print(f"[USERNAME] Captured: '{username}'")

    resp = say_and_gather_dtmf(
        f"Thank you {username}. "
        "Please enter your 4 digit PIN using the keypad.",
        action=f"/get_pin?call_sid={call_sid}",
        num_digits=4
    )
    return Response(str(resp), mimetype="text/xml")


# ══════════════════════════════════════════════════════
#  STEP 3 — Capture PIN
# ══════════════════════════════════════════════════════

@app.route("/get_pin", methods=["POST"])
def get_pin():
    call_sid = request.args.get("call_sid") or request.form.get("CallSid", "")
    digits   = request.form.get("Digits", "").strip()

    print(f"[PIN] Received: '{digits}' | SID: {call_sid}")

    if not digits or len(digits) != 4:
        resp = say_and_gather_dtmf(
            "Please enter your 4 digit PIN using the keypad.",
            action=f"/get_pin?call_sid={call_sid}",
            num_digits=4
        )
        return Response(str(resp), mimetype="text/xml")

    if call_sid in sessions:
        sessions[call_sid]["pin"]  = digits
        sessions[call_sid]["step"] = "await_command"

    print(f"[PIN] Captured for {call_sid}")

    resp = say_and_gather_speech(
        "PIN received. "
        "Please say your command. "
        "For example: send 500 rupees to Ali. "
        "Or say: check my balance.",
        action=f"/get_command?call_sid={call_sid}",
        timeout=6
    )
    return Response(str(resp), mimetype="text/xml")


# ══════════════════════════════════════════════════════
#  STEP 4 — Capture Command + Process
# ══════════════════════════════════════════════════════

@app.route("/get_command", methods=["POST"])
def get_command():
    call_sid = request.args.get("call_sid") or request.form.get("CallSid", "")
    speech   = request.form.get("SpeechResult", "").strip()

    print(f"[COMMAND] Heard: '{speech}' | SID: {call_sid}")

    if not speech:
        resp = say_and_gather_speech(
            "Sorry, I did not catch that. Please say your command clearly.",
            action=f"/get_command?call_sid={call_sid}",
            timeout=6
        )
        return Response(str(resp), mimetype="text/xml")

    # Get session data
    session  = sessions.get(call_sid, {})
    sender   = session.get("sender", "")
    pin      = session.get("pin", "")

    if not sender or not pin:
        resp = say("Session expired. Please call again.")
        resp.hangup()
        return Response(str(resp), mimetype="text/xml")

    # Extract intent
    print(f"[COMMAND] Extracting intent from: '{speech}'")
    intent = extract_intent(speech)
    print(f"[COMMAND] Intent: {json.dumps(intent)}")

    # Call backend
    result = call_backend(intent, sender, pin)
    print(f"[RESULT] {result}")

    # Speak result + ask for another transaction
    resp   = VoiceResponse()
    gather = Gather(
        input="dtmf",
        num_digits=1,
        action=f"/another?call_sid={call_sid}",
        timeout=5,
        method="POST"
    )
    gather.say(
        f"{result}. "
        "Would you like another transaction? "
        "Press 1 to continue, or hang up to end.",
        voice=VOICE,
        language=LANGUAGE
    )
    resp.append(gather)
    resp.say("Thank you for using VoicePay. Goodbye!", voice=VOICE, language=LANGUAGE)
    resp.hangup()

    return Response(str(resp), mimetype="text/xml")


# ══════════════════════════════════════════════════════
#  STEP 5 — Another Transaction?
# ══════════════════════════════════════════════════════

@app.route("/another", methods=["POST"])
def another():
    call_sid = request.args.get("call_sid") or request.form.get("CallSid", "")
    digits   = request.form.get("Digits", "").strip()

    if digits == "1":
        resp = say_and_gather_speech(
            "Please say your next command.",
            action=f"/get_command?call_sid={call_sid}",
            timeout=6
        )
        return Response(str(resp), mimetype="text/xml")

    resp = VoiceResponse()
    resp.say("Thank you for using VoicePay Pakistan. Have a great day!",
             voice=VOICE, language=LANGUAGE)
    resp.hangup()
    sessions.pop(call_sid, None)
    return Response(str(resp), mimetype="text/xml")


# ══════════════════════════════════════════════════════
#  INTENT EXTRACTOR — Groq + rule-based fallback
# ══════════════════════════════════════════════════════

GROQ_PROMPT = """You are the intent engine for VoicePay Pakistan.
Input is English text from speech recognition.

Return ONLY a raw JSON object — no markdown, no explanation.

{"action": "...", "amount": ..., "recipient": ...}

action    → "send" | "balance" | "unknown"
amount    → integer rupees only, or null
recipient → lowercase first name only, or null

Examples:
"Send 500 rupees to Ali"              → {"action":"send","amount":500,"recipient":"ali"}
"What is my balance"                  → {"action":"balance","amount":null,"recipient":null}
"mere account se Aslam ko 500 bhejo" → {"action":"send","amount":500,"recipient":"aslam"}
"""


def extract_intent(text: str) -> dict:
    key = os.environ.get("GROQ_API_KEY", "").strip()
    if not key:
        print("[GROQ] No key — using rule-based fallback")
        return _rules(text)

    try:
        from groq import Groq
        client   = Groq(api_key=key)
        response = client.chat.completions.create(
            model="llama-3.3-70b-versatile",
            messages=[
                {"role": "system", "content": GROQ_PROMPT},
                {"role": "user",   "content": f'Voice input: "{text}"'}
            ],
            temperature=0.0,
            max_tokens=100,
        )
        raw = response.choices[0].message.content.strip()
        raw = re.sub(r"^```[a-z]*\s*|\s*```$", "", raw).strip()
        p   = json.loads(raw)

        action = str(p.get("action", "unknown")).lower()
        if action not in ("send", "balance", "unknown"):
            action = "unknown"

        try:    amount = int(p["amount"]) if p.get("amount") is not None else None
        except: amount = None

        r         = p.get("recipient")
        recipient = str(r).strip().lower() if r and str(r).lower() not in ("null","none","") else None

        return {"action": action, "amount": amount, "recipient": recipient}

    except Exception as e:
        print(f"[GROQ ERROR] {e} — using rule-based fallback")
        return _rules(text)


def _rules(text: str) -> dict:
    """Rule-based fallback — works offline."""
    t = text.lower()
    if any(w in t for w in ["send","transfer","pay","bhejo","de do","kar de","give"]):
        action = "send"
    elif any(w in t for w in ["balance","kitna","check","how much","batao"]):
        action = "balance"
    else:
        action = "unknown"

    m      = re.search(r"\b(\d+)\b", t)
    amount = int(m.group(1)) if m else None

    names     = ["ali","ahmed","aslam","sara","usman","bilal","hamza","fatima","zara","omar","ahmad"]
    recipient = next((n for n in names if n in t), None)

    return {"action": action, "amount": amount, "recipient": recipient}


# ══════════════════════════════════════════════════════
#  BACKEND CALL — Flask app.py
# ══════════════════════════════════════════════════════

def call_backend(intent: dict, sender: str, pin: str) -> str:
    if intent["action"] == "unknown":
        return "Sorry, I did not understand your command. Please try again."

    payload = {
        "action":    intent["action"],
        "sender":    sender,
        "pin":       pin,
        "recipient": intent.get("recipient"),
        "amount":    intent.get("amount"),
    }

    try:
        resp = requests.post(BACKEND_URL, json=payload, timeout=10)
        return resp.text.strip()
    except requests.exceptions.ConnectionError:
        return "Sorry, the payment service is currently unavailable. Please try again later."
    except Exception as e:
        return "An error occurred. Please try again."


# ══════════════════════════════════════════════════════
#  TEST ENDPOINT — visit in browser to verify
# ══════════════════════════════════════════════════════

@app.route("/test_voice", methods=["GET", "POST"])
def test_voice():
    """Visit http://localhost:5001/test_voice to verify TwiML is working."""
    resp = VoiceResponse()
    resp.say("Welcome to VoicePay. Independent test successful. Voice system is working correctly.",
             voice=VOICE, language=LANGUAGE)
    resp.hangup()
    return Response(str(resp), mimetype="text/xml")


# ══════════════════════════════════════════════════════
#  HEALTH CHECK
# ══════════════════════════════════════════════════════

@app.route("/", methods=["GET"])
def health():
    return (
        "VoicePay Voice Engine — RUNNING\n\n"
        f"TWILIO_ACCOUNT_SID  : {'SET' if ACCOUNT_SID   else 'NOT SET'}\n"
        f"TWILIO_AUTH_TOKEN   : {'SET' if AUTH_TOKEN     else 'NOT SET'}\n"
        f"TWILIO_PHONE_NUMBER : {TWILIO_NUMBER or 'NOT SET'}\n"
        f"GROQ_API_KEY        : {'SET' if os.environ.get('GROQ_API_KEY') else 'NOT SET'}\n"
        f"BACKEND_URL         : {BACKEND_URL}\n\n"
        "Endpoints:\n"
        "  POST /incoming    ← Twilio webhook\n"
        "  GET  /test_voice  ← Quick test\n"
    ), 200, {"Content-Type": "text/plain"}


# ══════════════════════════════════════════════════════
#  RUN
# ══════════════════════════════════════════════════════

if __name__ == "__main__":
    print()
    print("═" * 58)
    print("  🎙  VoicePay — Voice Interface (FIXED)")
    print("═" * 58)
    print(f"  Flask port  : 5001")
    print(f"  Test URL    : http://localhost:5001/test_voice")
    print(f"  Webhook     : https://hedge-falcon-handcart.ngrok-free.dev/incoming")
    print("─" * 58)
    print(f"  ACCOUNT_SID : {'✅ SET' if ACCOUNT_SID   else '❌ NOT SET'}")
    print(f"  AUTH_TOKEN  : {'✅ SET' if AUTH_TOKEN     else '❌ NOT SET'}")
    print(f"  PHONE       : {TWILIO_NUMBER or '❌ NOT SET'}")
    print(f"  GROQ_KEY    : {'✅ SET' if os.environ.get('GROQ_API_KEY') else '❌ NOT SET'}")
    print(f"  BACKEND     : {BACKEND_URL}")
    print("═" * 58)
    print()
    app.run(debug=False, port=5001)